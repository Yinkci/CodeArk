/*
 * WordPress wrapper for jQuery mmenu
 * Include this file after including the jquery.mmenu plugin for default WordPress support.
 */
!function(e){var s="mmenu";e[s].configuration.classNames.selected="current-menu-item",e("#wpadminbar").css("position","fixed").addClass("mm-slideout")}(jQuery);